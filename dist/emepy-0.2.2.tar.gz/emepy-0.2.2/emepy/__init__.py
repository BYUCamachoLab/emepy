"""
emepy

Eigenmode Expansion Python
"""

__version__ = "0.2.0"
__author__ = 'Ian Hammond'
__credits__ = 'BYU CamachoLab'